package com.pdf;

import java.io.FileOutputStream;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
 

public class JavaPdfTable
{

   public static void main(String[] args)
   {
       Document document = new Document();
       try
       {
           PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("TableExample.pdf"));
           document.open();
    
           PdfPTable table = new PdfPTable(5); // 5 columns.
           table.setWidthPercentage(100); //Width 100%
           table.setSpacingBefore(10f); //Space before table
           table.setSpacingAfter(10f); //Space after table
    
           //Set Column widths
           float[] columnWidths = {1f, 1f, 1f, 1f, 1f};
           table.setWidths(columnWidths);
    
           PdfPCell SlNO = new PdfPCell(new Paragraph("SlNO"));
           SlNO.setBorderColor(BaseColor.BLACK);
           SlNO.setPaddingLeft(10);
           SlNO.setHorizontalAlignment(Element.ALIGN_CENTER);
           SlNO.setVerticalAlignment(Element.ALIGN_MIDDLE);
    
           PdfPCell Name = new PdfPCell(new Paragraph("Name"));
           Name.setBorderColor(BaseColor.BLACK);
           Name.setPaddingLeft(10);
           Name.setHorizontalAlignment(Element.ALIGN_CENTER);
           Name.setVerticalAlignment(Element.ALIGN_MIDDLE);
    
           PdfPCell Status = new PdfPCell(new Paragraph("Status"));
           Status.setBorderColor(BaseColor.BLACK);
           Status.setPaddingLeft(10);
           Status.setHorizontalAlignment(Element.ALIGN_CENTER);
           Status.setVerticalAlignment(Element.ALIGN_MIDDLE);
           
           PdfPCell Transaction = new PdfPCell(new Paragraph("Transaction"));
           Transaction.setBorderColor(BaseColor.BLACK);
           Transaction.setPaddingLeft(10);
           Transaction.setHorizontalAlignment(Element.ALIGN_CENTER);
           Transaction.setVerticalAlignment(Element.ALIGN_MIDDLE);
           
           PdfPCell Amount = new PdfPCell(new Paragraph("Amount"));
           Amount.setBorderColor(BaseColor.BLACK);
           Amount.setPaddingLeft(10);
           Amount.setHorizontalAlignment(Element.ALIGN_CENTER);
           Amount.setVerticalAlignment(Element.ALIGN_MIDDLE);
    
           //To avoid having the cell border and the content overlap, if you are having thick cell borders
           //cell1.setUserBorderPadding(true);
           //cell2.setUserBorderPadding(true);
           //cell3.setUserBorderPadding(true);
    
           table.addCell(SlNO);
           table.addCell(Name);
           table.addCell(Status);
           table.addCell(Transaction);
           table.addCell(Amount);
    
           document.add(table);
    
           document.close();
           writer.close();
       } catch (Exception e)
       {
           e.printStackTrace();
       }
   }
}
   /*{
      Document document = new Document();
      try
      {
         PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("HelloWorld.pdf"));
         document.open();
         document.add(new Paragraph("A Hello World PDF document."));
         document.close();
         writer.close();
      } catch (DocumentException e)
      {
         e.printStackTrace();
      } catch (FileNotFoundException e)
      {
         e.printStackTrace();
      }
   }
}
*/