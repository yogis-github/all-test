package com.example.demo

data class BankResJson(
        val RefId: String,
        val TranTime: String = "",
        val Amount: Int,
        val Status: String = "",
        val Reason: String = ""

)