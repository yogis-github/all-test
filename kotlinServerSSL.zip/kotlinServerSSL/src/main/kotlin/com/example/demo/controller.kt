package com.example.demo


import com.fasterxml.jackson.databind.util.JSONPObject
import com.google.gson.JsonObject
import org.apache.juli.logging.LogFactory
import org.slf4j.LoggerFactory
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*



@RestController
class Controller {


    val logger=LoggerFactory.getLogger(Controller::class.java)



    @PostMapping("/apiconnect/heartbeats",produces = arrayOf("application/json","application/xml"), consumes = arrayOf("application/json","application/xml"))
    fun apiSupport(@RequestBody i: Any?): ResponseEntity<String>? {

        println(i.toString())


        logger.info("Received "+i.toString())

        return ResponseEntity.status(200).body("SUCCESS")

    }


}